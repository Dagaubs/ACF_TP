package exportScala

// à remplacer par le code Scala exporté depuis la théorie Isabelle du tp2/3

object tp3 {
  def egal[T](l1: List[T], l2: List[T]): Boolean = ???
  def inter[T](l1: List[T], l2: List[T]): List[T] = ???
  def union[T](l1: List[T], l2: List[T]): List[T] = ???
}