package tester
import toTest._
import exportScala._

object MainTest extends App {	
  // La ligne nécessaire pour pouvoir utiliser le code généré par Isabelle/HOL
   // Definit HOL.equal[T] pour tout type T comme étant l'égalité Scala ==

/**   // A décommenter!!!
  
//	implicit def equal_t[T]: HOL.equal[T] = new HOL.equal[T] {
//		val `HOL.equal` = (a: T, b: T) => a==b
//	}
*/
  
  	
  // on lance l'application de test
	runTests
 
	// Deux ensembles représentés par des listes sont égaux si 
	// 1. tous les éléments n'apparaissent qu'une seule fois
  // 2. les listes sont identiques modulo une permutation 
	
	def egalListSet[T](l1:List[T],l2:List[T])= (l1.toSet.size == l1.size) && (l2.toSet.size== l2.size) && (l1.toSet == l2.toSet)
	  
	def runTests{
	  val allImp=List[tester.SetImpl](Imp1,Imp2,Imp3,Imp4,Imp5)
	  for(imp<- allImp){  
  	  try{
    		  // Les listes données en entrée sont censées ne pas contenir de doublons
  	  		val l1= List(1,2,3)
  	  		val l2= List(4,5)
  			  if (tp3.egal(l1,l2)!= imp.egal(l1,l2)) {println(imp.getClass.toString+" Equality problem: "+l1+" "+l2+" result is "+imp.egal(l1,l2)); throw Bug}
  			  if (! egalListSet(tp3.inter(l1,l2),imp.inter(l1,l2))) {println(imp.getClass.toString+" Intersection problem: "+l1+" "+l2+" result is "+imp.inter(l1,l2)); throw Bug}
  			  if (! egalListSet(tp3.union(l1,l2),imp.union(l1,l2))) {println(imp.getClass.toString+" Union problem: "+l1+" "+l2+" result is "+imp.union(l1,l2)); throw Bug}
  	  }
  	  catch{
	      case Bug => println("Terminated on bug!") 
	    }
	  }
	}
}

case object Bug extends Exception